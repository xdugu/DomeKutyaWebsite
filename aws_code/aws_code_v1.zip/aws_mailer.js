process.env[‘PATH’] = process.env[‘PATH’] + ‘:’ + process.env[‘LAMBDA_TASK_ROOT’]

var nodemailer = require('nodemailer'); 
var path = require('path');
const Email = require('email-templates');


 
const email = new Email({
  message: {
    from: 'mail.yatitrend@gmail.com'
  },
  // uncomment below to send emails in development/test env:
   send: true,
  transport: nodemailer.createTransport({
			  service: 'gmail',
			  auth: {
				user: 'mail.yatitrend@gmail.com',
				pass: 'alikem1995'
			  }
			})
	});
 
/*
  email.send({
			template: msg.template,
			message: {
			  to: msg.to,
			  bcc: msg.bcc
			},
			locals:  msg.locals
			
		  }).catch(console.error){};

*/

console.log("Everything seems to be okay");


